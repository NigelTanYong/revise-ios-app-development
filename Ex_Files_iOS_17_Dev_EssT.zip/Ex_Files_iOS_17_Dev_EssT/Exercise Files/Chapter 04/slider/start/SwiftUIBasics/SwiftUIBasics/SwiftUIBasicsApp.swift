//
//  SwiftUIBasicsApp.swift
//  SwiftUIBasics
//
//  Created by Todd Perkins on 10/9/23.
//

import SwiftUI

@main
struct SwiftUIBasicsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
