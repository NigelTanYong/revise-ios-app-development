//
//  WeatherUtilApp.swift
//  WeatherUtil
//
//  Created by Todd Perkins on 10/17/23.
//

import SwiftUI

@main
struct WeatherUtilApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
